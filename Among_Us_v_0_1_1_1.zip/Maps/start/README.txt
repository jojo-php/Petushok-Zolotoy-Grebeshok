For play among us click on file "Among Us.bat"
----------------------------------------------
--------------------------------------------------
Thank For Playing Among Us! Good Luck!